# QC v1.71 작업 요약 (2026-06)

QC v1.71 규격(품질Agent 외부연동, `품질Agent_외부연동_규격서_20260305_v1.71.docx`)에 대한
전수 검증 + emit 경로 결함 수정 사이클의 작업 요약. 명령별 스펙 대조/검증 이력은 `README.md` 참조.

- 결과물: 커밋 `61409a6f` "QC v1.71: emit-path fixes, storm gate, MUT producer rework" (81 파일)
- 추가 작업: per-command storm gate 신설, MUT producer 재설계, 디바이스 실기 검증
- 대상 디바이스: MAU7200EA (serial 13130067900061)

## 1. 적용된 수정 (커밋 61409a6f)

| 영역 | 파일 수 | 주요 변경 |
|------|---------|-----------|
| service/native-dm | 45 | emit gate/policy, SIP/IPv6/multicast, HMF, memory/action, event_dispatcher, monitors |
| service/pvs | 9 | 연결 전 emit 큐잉+replay, INF dedupe, PVS 시각, setErrorCode 라우팅 |
| lgumw/mediaCore/libmediacore | 10 | EMM/CHC/CHD/SIE 측정, qlas_stats_collector, ctc_event_sender, drm |
| device/sepolicy | 4 | CEC/DV genfs relabel, property/file/marusystem.te |
| apps/MaruDeviceManager | 4 | USB KEY 중복 제거, dead observer 삭제, 3PL 앱 정책 |
| apps/RcuManager | 1 | RcuService: rcu_battery_type/rcu_stb_fw producer, getStbLast NPE 가드 |
| service/snmpsub | 2 | cfgVersionDataRequest OID → SEA 트리거 |
| lgumw/iptvsystemservice | 1 | 3PL no-reboot PVS 리턴스트링 fallback |

신규 파일:
- `service/native-dm/api/qc/qc_emit_gate.h` — per-command storm gate
- `service/native-dm/api/qc/qc_emit_policy.h` — 명령별 rate-limit 정책
- `service/native-dm/api/network/multicast_report.{cpp,h}` — 멀티캐스트 리포트
- `service/native-dm/tests/qc_emit_gate_test.cpp` — storm gate 단위테스트 8종

삭제 파일:
- `apps/MaruDeviceManager/.../handler/PowerObserver.java` — 인스턴스화된 적 없는 dead code

## 2. 핵심 설계 결정

### 2.1 emit 단일 관문 + storm gate
모든 자발적(spontaneous) emit은 `QcAgentEmitter::emitRaw` 단일 관문을 통과한다. 이 지점에
per-command storm gate를 삽입했다. 여러 모듈에서 동일 명령이 짧은 시간에 폭주(예: 채널 zapping,
네트워크 플래핑)할 때 QC Agent로 가는 intent 홍수를 막는다.

- `qc_emit_policy.h`: 명령별 (min-interval, window budget) + 전역 cap
  - 기본 `{1000ms, 30}`, KEY `{200ms, 60}`, CHC/CHD/SIE/CIG/SIG `{500ms, 60}`
  - 전역 window 600s, 전역 max 200
- `qc_emit_gate.h`: `allow(command, nowMs)` 판정, 첫 drop + window-reset 요약을 로그로 가시화
- 요청/응답(REQ/INT/RRD)은 `handleReq/handleInt/handleRrd`로 `makeResponse`를 거치므로 gate 미적용

### 2.2 MUT producer 재설계
이전 구현(PowerObserver / AudioMuteObserver / pollAudioMute)은 STREAM_MUTE broadcast를 관찰하려
했으나, 이 제품의 음소거 경로는 broadcast를 발생시키지 않는다:

```
RCU 음소거 키 -> PhoneWindowManager.maruApplyVolumeKey -> native-dm set_mute -> doSetMute -> genieaudio HAL
```

따라서 `doSetMute()` 성공 + 상태 전이 시점에 MUT를 emit하도록 변경했다(atomic dedupe, storm gate 자동
적용). dead 경로(PowerObserver / AudioMuteObserver / pollAudioMute / dispatchOneQcCommand)는 전부 삭제.

### 2.3 USB KEY 이중발행 제거
`DeviceManagerService.mUsbReceiver`가 `sendQcKeyEvent`로 직접 broadcast하고, framework
`UsbDeviceManager`도 native-dm 경유로 emit하여 USB 삽입/제거(KEY 5/6)가 이벤트당 2행 발행되던 문제.
`mUsbReceiver` 직접 경로를 제거해 native-dm 단일 경로로 일원화.

### 2.4 SIP gateway policy-table fix
Android 정책 라우팅은 default route를 인터페이스별 테이블(예: table 1014)에 두고 main 테이블
(`/proc/net/route`)은 비어 있을 수 있다. 이 때 SIP IPv4 gateway가 `0.0.0.0`으로 나가던 결함.
`network_info.cpp`의 `getGateway(iface)`가 dhcp 프로퍼티 이전에 `getDefaultGatewayIp(iface)`
(policy table 조회)를 우선 fallback하도록 수정. IPv6 Global/Local 분류도 정정.

### 2.5 getStbLast NPE 가드
`RcuService.getStbLastSoftwareAppPatchVersionAndFile`에서 `/data/lgu_app/rcu_fw` 부재 시
`listFiles()`가 null을 반환해 `files.length`에서 NPE. `files != null && files.length > 0` 가드 추가.
rcu_stb_fw 발행 + 기존 updateRcu/RPT 경로의 잠복 버그였다(디바이스 logcat에서 RCU 페어링 중 발견).

### 2.6 3PL PVS 리턴스트링 fallback
`persist.vendor.prop.no_reboot=yes`(3PL no-reboot 모드)에서 PVS 정상 프로비저닝이 생략될 때,
`IptvSystemService`가 PVS 리턴스트링을 구성해 반환하는 fallback(`buildThreePlPvsReturnString`).

### 2.7 SNMP SEA 트리거
`cfgVersionDataRequest` OID `1.3.6.1.4.1.11665.20.3.47` SET을 QC SEA 트리거로 라우팅
(`MSG_CFG_VERSION_DATA`). snmpsub `config_handler.cpp` + `snmp_msg.h`.

### 2.8 DIAG emit 로그
`qc_agent_emitter.cpp`의 emit 로그를 `QcAgentEmitter: emit cmd=%s data=%s` 단일 라인으로 통합.
full payload가 그대로 보여 디바이스에서 `grep "cmd=X data="`로 필드 단위 검증이 가능하다(영구 유지).

## 3. 디바이스 실기 검증 (serial 13130067900061)

burn 후 실기에서 확인한 항목:

| 명령 | 검증 결과 |
|------|-----------|
| MUT | 음소거 키 -> doSetMute -> `cmd=MUT|1`/`|0` 2필드, dedup |
| RST | `sys.marusys.qc.rst_emitted=1` 마커 (재시작 중복방지) |
| SIP | 버그조건 재현(default route가 table 1014에만) -> fix가 GW 정상 emit. IPv6 2406::/3 Global 분류 |
| LID/LIU | 단일 emit, 유선 빈 tail, 오염/폭주 없음 |
| HMF | 22필드, resolution 1080p@60 / HDR NA / CEC 1(fun_cfg genfs) / TV모델 osd_name genfs / port 1~4 클램프 |
| RCU 페어링 | RON(pairing-complete, duration %.1f) / RPT(11필드) / BCO. rcu_battery_type producer 동작 |
| RCU 언페어 | BDC(reason 0x16) / ROF(6필드) / rcuconnected 1->0 / disconnect_count++ |

미검증(트리거 환경 필요): CHC/CHD/SIE/EMM(IPTV 재생+zapping), EOF(헤드셋), SIF grace(DHCP 실패),
RRD 실응답(QC Agent 요청).

## 4. 빌드/배포 상태

- native-dm md5 `ccb563a4`, RcuManager md5 `81248a5c` 디바이스 반영 확인
- repo sync 후 커널(common14-5.15) + android 재빌드, 새 커널 정상 부팅 확인
  (`5.15.196-android14-11-g9fe0dc749c39-ab02.02.0000`, dmesg panic/oops/unknown-symbol 0)
- 디바이스 bootloader unlock + disable-verity + remount 완료(개별 바이너리 push 가능)

## 5. 후속 / 미결

- codex 전수 재리뷰 리포트: `/home/kyc/tmp/qc_review/FINAL_REPORT.md`, `FIX_WAVE_REPORT.md`
  (확정 신규이슈 목록 + 수정 매트릭스). 일부는 device-dependent 또는 U+ 확인 대기.
- U+ 확인 필요: BCO 필드8, BDC 사유 문자열, HMF DV Mode 문자열, QC 앱팀 ACCEPT_PACKAGES/S·REQ marusys 분기
- RST type2(40시간 주기 리셋) 트리거 주체 구현 필요(classify 매핑은 완료, `reboot,scheduled` 발화 주체 미구현)
- AIDL `marusys-devicemanager`는 다음 부 출시 직전 `frozen: true` 전환 예정
