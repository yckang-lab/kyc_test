# Fastboot Channel Banner Rendering Analysis

sb2 레퍼런스 기기에서 fastboot 채널번호 OSD가 어떻게 그려지는지 확인한 내용 정리.


## 1. 렌더링 방식

sb2를 보면 Skia 기반 네이티브 UI로 채널 배너를 그리고 있다.

- OSD surface 해상도: **960x540** (SD)
- Skia SkCanvas에 직접 drawText
- SoC 벤더(Synaptics) GFX HAL 위에 surface 생성


## 2. 폰트

### 채널 번호

- **NanumGothicBold.ttf** (`/vendor/fonts/`)
- 960x540 기준 **63px**, 720p에서는 **80px**

### 채널 이름

- **YoonGothic540.ttf** (`/vendor/fonts/`)
- **20px**

### 기기에 탑재된 폰트 파일들

```
/vendor/fonts/YoonGothic540.ttf       일반 텍스트 (기본 폰트)
/vendor/fonts/NanumGothicBold.ttf     채널번호, 대형 텍스트
/vendor/fonts/Roboto-Regular.ttf      fallback
/vendor/fonts/YoonGothic750.ttf       업그레이드 화면 본문
/vendor/fonts/YoonGothic770.ttf       업그레이드 화면 제목
/vendor/fonts/BebasNeue-Regular.ttf   업그레이드 화면 숫자(%)
```


## 3. 레이아웃

960x540 기준 우측상단 배치:

```
+--960------------------------------------------+
|                                  +-180-+       |
|                                  | 123 | 34px  |
|                                  | MBC |       |
|                      48px margin +-----+       |
|                                                |
+------------------------------------------------+
```

| 항목 | 값 |
|------|----|
| 화면 우측 여백 | 48px |
| 화면 상단 여백 | 34px |
| 배너 영역 | 180 x 130px |
| 채널번호 | 우측 정렬 (right offset 0px) |
| 채널이름 Y 오프셋 | 63px (채널번호 아래) |
| 텍스트 색상 | `#CCCCCC` (밝은 회색) |
| 드롭 쉐도우 | 없음 (코드에 있으나 비활성) |

720p에서는 배너 너비 240px, 채널이름 Y 오프셋 90px으로 보정.


## 4. 그리기 순서

```
1. 채널번호 문자열 준비 ("123" 등)
2. NanumGothicBold 63px 폰트 설정
3. 텍스트 폭 측정 -> 배너 우측에서 빼서 우측 정렬
4. baseline 기준으로 Y 보정
5. #CCCCCC 색상으로 drawText
6. 채널이름 문자열 준비 ("MBC" 등)
7. YoonGothic540 20px 폰트 설정
8. 채널번호 아래 63px 지점에 UTF-8 drawText
```


## 5. MAU7200EA와 비교

| 항목 | sb2 | MAU7200EA |
|------|-----|-----------|
| 렌더링 엔진 | Skia (네이티브 GFX HAL) | Skia (MaruSkiaService) |
| OSD 해상도 | 960x540 | 1920x1080 |
| 채널번호 폰트 | NanumGothicBold 63px | YoonGothic750 96px |
| 채널이름 폰트 | YoonGothic540 20px | YoonGothic750 40px |
| 텍스트 색상 | #CCCCCC | #EEEEEE |
| 드롭 쉐도우 | 없음 | 있음 (3px, blur 1.5px) |
| 우측 여백 | 48px (960x540) | 60px (1920x1080) |
| 배너 트리거 | UI thread 직접 | Binder IPC (native-dm -> MaruSkiaService) |
