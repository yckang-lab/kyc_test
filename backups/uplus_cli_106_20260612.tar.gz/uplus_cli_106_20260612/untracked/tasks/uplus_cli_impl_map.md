# uplus-cli 명령별 구현 위치 / 실측 결과

실측: 2026-06-12, MAU7200EA(13130067900061), eth0(192.168.123.107), telnet :23.
원시 캡처: `/home/kyc/tmp/cli_smoke/full_capture.txt`.
경로 약어: clid=`service/uplus-cli`, ndm=`service/native-dm`.
명령 라우팅 공통: telnet → clid `core/cli_parser.cpp:23`(명령 테이블) → `commands/*.cpp` →
(원격형) Binder `CLI_MSG_*`(`platform/cli_msg.h`) → ndm `handlers/cli_cmd.cpp` → api/store.

## 1. 네트워크 정보 (스펙 4.1)

| 명령 | clid 구현 | native-dm 경로 | 실측 결과 |
|---|---|---|---|
| show ip | remote_commands.cpp:379 cmdShowIp | querySysInfo(cli_query.cpp:110) keys: network_type/net_gateway/net_dns/net_ssid/net_link_speed → network_info.cpp(getGateway/getDns/getEthtoolLinkInfo), netmond(kFieldSsid) | PASS — LAN/DHCP/Optical/IP/Strength 1000 Mbps/GW/DNS(IPv6 2개)/MAC. WiFi 시 SSID=U+Net7581_5G 실측 |
| ip -i ... -s | remote_commands.cpp:1049 cmdIpStatic | CLI_MSG_IP_STATIC(cli_cmd.cpp:984) → api/network/network_config.cpp setStaticIp → 자동 reboot | PASS — Set Network Information 블록 + conf 기록(assignment=static) + 재부팅. 적용은 fastboot 부팅의 dhcp_client_service |
| ip -d on/off | remote_commands.cpp:1029 cmdIpDhcp | CLI_MSG_IP_DHCP(cli_cmd.cpp:969) → network_config.cpp setIpDhcp → reboot | PASS — DHCP:ON + assignment=dhcp + mirror(dhcp_mode) + 재부팅. off는 static 선설정 필요 가드 동작 |
| show wan | remote_commands.cpp:472 cmdShowWan | querySysInfo key net_wan_info → network_info.cpp getEthtoolLinkInfo(SIOCETHTOOL) | PASS — 1000 / Full / ON (기가비트 실측) |
| show usb | remote_commands.cpp:523 cmdShowUsb | (로컬) /sys/bus/usb/devices 직독 | PASS — 장치 미장착 상태라 헤더+OK (장착 시 목록) |
| diag ping server | local_commands.cpp:370 cmdDiagPing | (로컬) pvs.db 서버목록 → ping fork | PASS — 12개 서버 OK/N/A, 소요 ~25s |
| diag ping <ip> | local_commands.cpp:370 | (로컬) ping | PASS — `8.8.8.8 : OK` |
| show igmp | remote_commands.cpp:1257 cmdShowIgmp | CLI_MSG_QUERY_IGMP(cli_cmd.cpp:673) → querySiInfoLine(EpgMulticastState/마커 mtime) + player getEmmIpInfo | PASS — `DVB-SI : OK : 시각` + `EMM : 233.18.145.129 : 시각`(join 후). 미join 시 EMM FAILED |

## 2. 시스템 정보 (스펙 4.2)

| 명령 | clid 구현 | native-dm 경로 | 실측 결과 |
|---|---|---|---|
| show sys | remote_commands.cpp:576 cmdShowSys | CLI_MSG_QUERY_SYS_INFO_BATCH(cli_query.cpp:176) + props | PASS — Customer Id/MAC/날짜/H/W(ro.product.board)/Loader/F/W/MA·IUI·PS/Config·Xait Ver/Status |
| sys init | remote_commands.cpp:775 cmdSysInit | CLI_MSG_SYS_INIT(cli_cmd.cpp:746) → system_action | 미실측(파괴적) — 검수 단계 |
| reboot | remote_commands.cpp:767 cmdReboot | CLI_MSG_REBOOT(cli_cmd.cpp:681) → SystemCommander::reboot | PASS — 즉시 재부팅 실측 |
| show pvs | remote_commands.cpp:687 cmdShowPvs | CLI_MSG_QUERY_PVS_INFO → queryPvsInfo(cli_query.cpp:24, pvs.db) | PASS — Provisioning/Customer Id/Network Type Optical(코드매핑)/Config Ver |
| show server | remote_commands.cpp:711 cmdShowServer | queryServerInfo(cli_query.cpp:34, pvs.db) | PASS — IMCS/Provisioning/DRM/CDN 3종 |
| password init | remote_commands.cpp:779 cmdPasswordInit | CLI_MSG_PWD_INIT(cli_cmd.cpp:785) → UP(SecretNum=0000) | PASS — OK |
| show screen | remote_commands.cpp:1203 cmdShowScreen | queryScreenInfo(cli_query.cpp:84) → stb_info getDisplayUiMode | PASS — TV:HD / Aspect 16:9 / Resolution 1080p (레퍼런스 3행) |
| show caption | remote_commands.cpp:1214 cmdShowCaption | CLI_MSG_QUERY_CAPTION(cli_cmd.cpp:661) → UP CAPLANG | PASS — Language: Unknown(미설정 상태값; K/E/H 매핑 구현) |
| show resource | remote_commands.cpp:614 cmdShowResource | (로컬) statvfs/meminfo/loadavg/uptime | PASS — HDD1 17G/18G·Flash·RAM·CPU·UPTIME |
| show user | remote_commands.cpp:1220 cmdShowUser | queryUserInfo(cli_query.cpp:80) | PASS — admin/iptvuser/iptvsvc 3행 |
| show config | remote_commands.cpp:735 cmdShowConfig | queryConfig(cli_query.cpp:45, pvs.db+config.xml) | PASS — Config 3812/Xait 578/Checktime/FW/BW |
| factory reset | remote_commands.cpp:771 | CLI_MSG_FACTORY_RESET(cli_cmd.cpp:737) | 미실측(파괴적) — 검수 단계 |
| resolution -t -r | remote_commands.cpp:787 cmdResolution | CLI_MSG_RESOLUTION(cli_cmd.cpp:1045) → SystemCommander::setResolution → applyResolutionViaJavaDm(Java DM commit, HAL 폴백) | PASS — 720p 실전환(sysfs 720p60hz)·유지·1080p 복귀 |
| cp -d on/off | remote_commands.cpp:979 cmdCpProtection | CLI_MSG_CP_PROTECTION(cli_cmd.cpp:1057) → setCopyProtection(persist.vendor.sys.hdcp.disable) | PASS — HDCP ON/OFF + prop 실반영(vendor_customer_prop). HWC 읽기 te 추가됨 |
| fw upgrade | remote_commands.cpp:783 | CLI_MSG_FW_UPGRADE(cli_cmd.cpp:764) | 미실측(펌웨어 교체) — 검수 단계 |
| setpvs tb/da/po | remote_commands.cpp:868 cmdSetPvs | CLI_MSG_SET_PVS(cli_cmd.cpp:773) → setPvsServer(prop+reboot) | 회신 포맷 PASS(스모크). 실전환 보류(PVS 서버 변경) |
| igmp join/leave si | remote_commands.cpp:829 cmdIgmp | (clid에서 si 거절) | PASS — `NOT SUPPORTED!!!` (레퍼런스 동일) |
| igmp join/leave emm | remote_commands.cpp:829 | CLI_MSG_IGMP_JOIN/LEAVE(cli_cmd.cpp:1002) → IIptvPlayService startEmm/stopEmm/isFirstEmmReceived/getEmmIpInfo → MediaCoreHal_Drm_* | PASS — join `233.18.145.129 5490 join OK` / leave OK (유선 실수신) |
| igmpip ip port | remote_commands.cpp:851 cmdIgmpIp | CLI_MSG_IGMP_IP(cli_cmd.cpp:1013) → raw socket join+recv(2s)+leave | PASS — `join and recv data OK` + `leave OK` (유선). 기join 시 Already 문구 |
| channel up/down | remote_commands.cpp:820 cmdChannel | CLI_MSG_CHANNEL_UP/DOWN(cli_cmd.cpp:1023) → uinput injectChannelUp/Down + playback_ready 폴링(7.5s) | PASS — 990→999→990 양방향 |
| dca <n> | remote_commands.cpp:861 cmdDca | CLI_MSG_DCA_CHANNEL(cli_cmd.cpp:1034) → injectChannelNumber(1s 간격) + 폴링 | PASS — 990→5 (단일 digit 커밋 확인) |
| standbytime [h] | remote_commands.cpp:887 cmdStandbyTime | CLI_MSG_STANDBY_TIME(cli_cmd.cpp:794) → settings.db | PASS — GET 0 / SET 3 / 0=disable 문구 |
| sys qms tb/co | remote_commands.cpp:928 cmdSysQms | CLI_MSG_QMS_SERVER(cli_cmd.cpp:901) → 토큰→URL 매핑 settings.db | PASS — Commercial/TestBed URL 출력 |
| show area | remote_commands.cpp:1231 cmdShowArea | queryAreaInfo(cli_query.cpp:74, pvs.db locale) | PASS — `011\|013\|012` |
| hotelservice | remote_commands.cpp:946 cmdHotelService | CLI_MSG_HOTEL_SERVICE(cli_cmd.cpp:826) → UP HOTELSERVICE | PASS — on 10(Barker CH:10)/off |
| show thres | remote_commands.cpp:1240 cmdShowThres | CLI_MSG_QUERY_THRES(cli_cmd.cpp:892) → settings.db | PASS — ifconfig=1, PCR=1, NoDecoding=1, RTP=1, NoStream=1 |
| thres a,b,c,d,e | remote_commands.cpp:1085 cmdThres | CLI_MSG_THRES(cli_cmd.cpp:872) → setThresholds + QlasMonitor reload | PASS — pipe 저장(QLAS와 포맷 일치) |
| netstat ... | local_commands.cpp:493 cmdNetstat | avstream만 CLI_MSG_QUERY_AVSTREAM(QLAS snapshot), 나머지 로컬(/proc) | PASS — avstream 23행/eth0·wlan0 통계/igmp/tcp/udp |
| barkerchmode | remote_commands.cpp:966 cmdBarkerChMode | CLI_MSG_BARKER_CH_MODE(cli_cmd.cpp:842) → UP BKCHMODE true/false | PASS — on/off |
| show paring(/pairing) | remote_commands.cpp:1251 cmdShowParing | CLI_MSG_QUERY_PAIRING(cli_cmd.cpp:667) → vendor.bluetooth.* props | PASS — RCU/KIDS RCU Not Paired(BT RCU 미페어 상태값) |
| standbyreboot [h] | remote_commands.cpp:910 cmdStandbyReboot | CLI_MSG_STANDBY_REBOOT(cli_cmd.cpp:810) → settings.db | PASS — GET 40 / SET 48→40 복원 |
| setRGrade [0/1] | remote_commands.cpp:1001 cmdSetRGrade | CLI_MSG_SET_RGRADE(cli_cmd.cpp:855) → UP RCAT | PASS — GET Unknown(미설정)/on/off |
| setHomeShoppingCh | (제거) | (제거 — v1.4.33 삭제 항목) | N/A — help에도 없음 확인 |

## 3. 로그 관리 (스펙 4.3)

| 명령 | clid 구현 | native-dm 경로 | 실측 결과 |
|---|---|---|---|
| show log | local_commands.cpp:77 cmdShowLog | (로컬) /LGU_data/pvs 로그 30개씩 | PASS — `>> Log` + Error/General 각 30 |
| log init | local_commands.cpp:98 cmdLogInit | (로컬) 로그 삭제 | PASS — `>> Init Log >> OK` |
| nms pull | remote_commands.cpp:1022 cmdNmsPull | CLI_MSG_NMS_PULL(cli_cmd.cpp:1093) → sys.pvs.immediate=start_nms (pvsd) | PASS — NMS PULL OK |

## 4. 기타 (스펙 4.4)

| 명령 | clid 구현 | 실측 결과 |
|---|---|---|
| help | local_commands.cpp:25 + cli_parser getHelp(std::sort) | PASS — 알파벳순 전체 목록(setting init/nms url 없음, show qc 있음) |
| start-shell | local_commands.cpp:37 cmdStartShell | PASS — 셸 진입(uid=0, marusystem ctx) → exit 시 CLI 복귀 |
| exit | local_commands.cpp:31 cmdExit | PASS — 세션 종료(전 테스트에서 상시 사용) |

## 5. 추가 스펙 (debuglog/QLAS/QC/hidden-qc/autotest)

| 명령 | clid 구현 | native-dm 경로 | 실측 결과 |
|---|---|---|---|
| debuglog upload | remote_commands.cpp:1109 cmdFulllogUpload | CLI_MSG_FULLLOG_UPLOAD(cli_cmd.cpp:691) → log-uploader | PASS — `OK` (실서버 업로드 성공) |
| debuglog server | remote_commands.cpp:1114 cmdFulllogServer | CLI_MSG_FULLLOG_SERVER(cli_cmd.cpp:719) → settings.db fulllog_server | PASS — 조회 hdslog.lguplus.co.kr / set `Debuglog server changed:` / 키 포함 `ip port with key`. 부팅 시 초기화 구현·검증(native_dm_service.cpp init에서 키 삭제 → 기본 hdslog 복귀; SNMP .20.3.13 공유 키도 동일 적용) |
| debuglog autosend | remote_commands.cpp:1140 cmdQcAutosend | CLI_MSG_QC_AUTOSEND(cli_cmd.cpp:625) | PASS — on/off/조회 echo |
| show qlas-data | remote_commands.cpp:1158 | CLI_MSG_QUERY_QLAS_DATA(cli_cmd.cpp:646) → QlasMonitor snapshot | PASS — count=23 + QMS 레코드 |
| show qc-data | remote_commands.cpp:1171 | CLI_MSG_QUERY_QC_DATA(cli_cmd.cpp:651) → QlasMonitor CSV | PASS — pcr/notdec/rtp/nostream/ifcfg 10슬롯 |
| show qc | remote_commands.cpp:1164 cmdShowQc | CLI_MSG_EXPORT_QC_DATA(cli_cmd.cpp:638) → /tmp/.qc_data_file | PASS — 파일 생성, proc count 576(readproc) |
| show hidden-qc | remote_commands.cpp:1189 | CLI_MSG_SHOW_HIDDEN_QC(cli_cmd.cpp:923) → HM open | PASS — `1` |
| close hidden-qc | remote_commands.cpp:1195 | CLI_MSG_CLOSE_HIDDEN_QC(cli_cmd.cpp:932) | PASS — `1` |
| autotest start | remote_commands.cpp:1177 | CLI_MSG_AUTOTEST_START → api/system/autotest_runner.cpp startAutoTestPlayback(uinput) | PASS — `1` + vendor.iptv.autotest=run, 스크립트 없으면 `0` |
| autotest stop | remote_commands.cpp:1183 | CLI_MSG_AUTOTEST_STOP → stopAutoTestPlayback | PASS — `1` + prop=stop (자연종료도 stop 전이) |

## 미실측/보류 사유 요약
- sys init / factory reset / fw upgrade: 파괴적 — 검수 단계 실행
- setpvs 실전환: PVS 서버 변경(개통 영향) — 회신 포맷만 확인
- debuglog server 재부팅 초기화: 구현 완료(2026-06-12) — set→native-dm 재시작→기본값 복귀 검증
