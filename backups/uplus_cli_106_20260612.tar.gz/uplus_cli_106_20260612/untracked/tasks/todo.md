# deepinit: hierarchical AGENTS.md generation (2026-06-11)

- [x] Map directory structure, check existing AGENTS.md (none found, fresh generation)
- [x] Agent 1: apps/ tree (27 files)
- [x] Agent 2: service/ root + native-dm subtree (12 files)
- [x] Agent 3: remaining services (23 files)
- [x] Agent 4: lgumw/ + libs/ + frameworks/ (20 files)
- [x] Agent 5: hardware/ device/ sepolicy/ external/ prebuilt/ script/ tools/ doc/ (12 files)
- [x] Root AGENTS.md (written directly)
- [x] Validate: 95 files, all Parent tags resolve, all "see X/AGENTS.md" cross-refs resolve, no forbidden tokens, no em dashes/emoji

## Review
- 95 AGENTS.md files generated across the tree; third-party source (external/), prebuilt/, doc/ kept to single overview files by design.
- Stale CLAUDE.md facts surfaced during verification (binder names, pvsd path, missing v7 doc, isAutosendOn) - candidates for a CLAUDE.md cleanup pass.
- .cursor/rules/function-comments-ko.mdc expects a Korean function-comment template in root AGENTS.md; conflicts with CLAUDE.md English-only rule - not added, flagged to user.
