# uplus-cli 106 작업본 통합 — 디바이스 테스트 매트릭스

## 최종 결과 (2026-06-12, burn 02.02.0000 + 수정분 push)

전 항목 PASS. burn 후 단계에서 발견·수정된 사항:

| 발견 | 수정 |
|---|---|
| show ip DNS가 IPv6에서 깨짐 (getDns ':' join이 IPv6 ':'와 충돌) | native-dm net_dns가 '\|'로 정규화, clid '\|' split |
| show screen이 Resolution 1행만 출력 | 레퍼런스 동작(TV/Aspect Ratio/Resolution 3행) + UI 토큰(getDisplayUiMode) |
| resolution 적용 후 framework가 즉시 원복 | HiddenMenu와 동일한 Java DM commit 경로(applyResolutionViaJavaDm)로 교체 — 720p 전환·유지·1080p 복귀 실측 |
| ip -d/-i가 "failed to open network config" | /LGU_data/marusys가 init.snmpd.rc의 mkdir 0755 system:system로 매부팅 회귀 → snmpd rc 0775 root system + native-dm rc에도 mkdir 추가 |

burn 후 실측 PASS 목록:
- show ip: Type=Optical(코드매핑) / SSID=U+Net7581_5G·Strength=100Mbps(netmond) / Gateway(policy route) / DNS IPv6 2개 정상
- show igmp: DVB-SI 행 + EMM ip:time (igmp join emm 후 233.18.145.129 : 시각 표시)
- igmp join/leave emm: player EMM AIDL 전 경로 동작 (join ERROR는 WiFi 멀티캐스트 미수신 환경 요인 — 유선 재확인 항목)
- cp -d on/off: persist.vendor.sys.hdcp.disable 실반영(vendor_customer_prop), HWC 읽기 te 추가됨
- resolution -t hd -r 720p/1080p: 실전환+유지+복귀
- autotest start/stop: TXT 스크립트 로드, vendor.iptv.autotest run→stop(자연종료/중간정지 모두)
- show qc: /tmp/.qc_data_file 생성, process count 576(readproc 적용)
- channel up: 폴링 검증창으로 OK 판정 (5→6 실제 zap)
- ip -d on / ip -i(static) / ip -d on 복구: config 기록+mirror+자동재부팅+Mode 표시 전부 동작.
  실제 인터페이스 적용은 fastboot 부팅(persist.vendor.fastboot.enabled=1)에서 dhcp_client_service가 수행 — 설계 의도(이 디바이스는 fastboot off라 framework DHCP 관할)
- password init: OK

유선(eth0) 재검증 추가분 (2026-06-12 오후):
- igmp join emm: join OK (실수신) / show igmp: DVB-SI OK + EMM ip:time 완성
- show wan: 1000/Full/ON (SIOCETHTOOL 신규 경로 — sysfs generic 라벨 문제 우회)
- show ip(유선): Type LAN, Strength 1000 Mbps, eth0 IP/MAC/GW/DNS 정상
- netmond linkSpeed=100 하드코딩 스텁 발견 — WiFi Strength 실측은 network team 구현 필요

남은 수동/환경 항목:
- igmp join emm 수신 OK 판정 + DVB-SI OK 판정: 유선(eth0) 환경에서 재확인
- HiddenMenu AutoTest 정지키/자연종료 UI 정리: RCU로 수동 확인 (코드 경로는 신규 추가됨)
- dca 단일 digit 커밋: 화면 보며 확인
- setpvs 실전환(tb→da): PVS 서버 전환이라 보류 — 운영 검수 시
- sys init / factory reset / fw upgrade: 파괴적 — 검수 단계에서

## 스모크 결과 요약 (2026-06-12, uplus-clid+native-dm push만)

- GET 23종 + SET 17종 실측 완료. 출력 포맷 전부 스펙/추가스펙 일치.
- 발견/수정 5건 (재빌드 대기):
  1. show ip "Type : 02" → RESSI 코드 매핑(01=HFC/02=Optical) 추가, show pvs도 적용
  2. show ip Gateway/DNS N/A → native-dm net_gateway/net_dns synthetic key 경유로 수정
     (Android policy routing 때문에 /proc/net/route만으론 못 읽음)
  3. show igmp DVB-SI 행 추가 (EpgAgent 수신상태+마커 mtime, SNMP cfgEmmEpg와 동일 소스)
  4. channel up 검증창 2s→7.5s 폴링 (zap 지연으로 성공을 ERROR 오판하던 것)
  5. QC process count 4 (hidepid) → init rc에 readproc 그룹 추가
- channel up 실제 zap은 성공 확인(9→10). dca 단일digit 커밋 동작은 화면 보며 확인 필요.
- igmpip ALREADY 감지 정상 (EpgAgent join 그룹). /tmp/.qc_data_file 생성+내용 정상, AVC 거부 없음.
- 잔여 갭(보류): show ip SSID/Strength(WiFi) — WifiManager 접근 필요, 후속 검토.
- 원복 완료: thres 1,1,1,1,1 / standbytime 0. debuglog server는 재부팅 시 init 초기화.
  setRGrade 0/barker off/hotel off 상태로 남음(기본값과 동일).


테스트 환경: 13130067900061 (192.168.123.106:23), telnet root 로그인.
단계: [스모크] = uplus-clid+native-dm push만으로 검증 가능 / [burn후] = 전체 이미지 필요
(sepolicy·dhcp_client·player·skia 의존).

## A. GET 명령 (스모크 단계)

| # | 명령 | 기대 출력 핵심 | 결과 |
|---|---|---|---|
| 1 | show ip | Type/Mode(network_config.conf)/Type(HFC·Optical)/IP/SSID/... | |
| 2 | show wan | 10/100, Half/Full, Auto-nego | |
| 3 | show usb | ">> USB Information" 헤더 | |
| 4 | show sys | H/W Version=ro.product.board | |
| 5 | show pvs | Provisioning/Customer Id/... | |
| 6 | show server | IMCS/Provisioning/DRM/... | |
| 7 | show screen | TV/Aspect/Output/Resolution | |
| 8 | show caption | "Language : Korean|English|Caption off" (CAPLANG) | |
| 9 | show resource | HDD/Flash/RAM/CPU/UPTIME | |
| 10 | show user | User1/User2/User3 | |
| 11 | show config | Config Ver/Xait Ver/... | |
| 12 | show area | "111\|112\|113" 형식 | |
| 13 | show thres | ifconfig=, PCR=, NoDecoding=, RTP=, NoStream= | |
| 14 | show paring / show pairing | RCU/KIDS RCU Paired(connected) | |
| 15 | show igmp | "EMM : ip : time" (player 구버전이면 FAILED 허용→burn후 재확인) | |
| 16 | show standbytime / standbyreboot | 현재값 출력 | |
| 17 | show log | ">> Log" 헤더 + err/normal 30개 | |
| 18 | show qlas-data / show qc-data | QLAS snapshot / CSV | |
| 19 | netstat avstream/eth0/igmp/tcp/udp | 표 형식 | |
| 20 | diag ping server / diag ping <ip> | OK/ERROR per server | |
| 21 | help | 알파벳순, setting init·nms url 없음, show qc 있음 | |
| 22 | debuglog server (조회) | 서버주소 or N/A | |
| 23 | debuglog autosend (조회) | "debuglog autosend is on/off" | |

## B. SET 명령 (개별 실행, 스모크 가능)

| # | 명령 | 기대 동작 | 결과 |
|---|---|---|---|
| 24 | channel up / channel down | OLD/NEW CH + OK (2s 검증) | |
| 25 | dca <ch> | OLD/NEW CH + OK (uinput digit, 1s 간격) | |
| 26 | igmpip 233.18.145.128 5490 | join+recv+leave 시퀀스 출력 | |
| 27 | thres 1,1,1,1,1 / show thres | 저장 + QLAS reload | |
| 28 | sys qms tb / co | URL 출력 + OK | |
| 29 | hotelservice on 10 / off | Barker CH 문구 | |
| 30 | barkerchmode on/off | BKCHMODE true/false | |
| 31 | setRGrade 0/1 | R Grade 문구 | |
| 32 | standbytime 24 / standbyreboot 48 | set 문구 | |
| 33 | debuglog server 1.2.3.4 8080 [key] | "Debuglog server changed:" / "with key" | |
| 34 | debuglog autosend on/off | 상태 echo | |
| 35 | debuglog upload | OK/NG (log-uploader) | |
| 36 | show qc | ">>Show QC data" + /tmp/.qc_data_file 생성 확인 | |
| 37 | show hidden-qc / close hidden-qc | 1/0 + 화면 확인 | |
| 38 | nms pull | ">> NMS PULL >> OK" + pvsd 동작 | |
| 39 | password init | OK | |
| 40 | igmp join si | "NOT SUPPORTED!!!" | |

## C. burn 후 검증 (sepolicy / player / skia / dhcp_client 의존)

| # | 명령 | 의존 | 결과 |
|---|---|---|---|
| 41 | igmp join emm / leave emm | player EMM AIDL (신규 4 메서드) | |
| 42 | show igmp (EMM ip:time 실값) | player getEmmIpInfo | |
| 43 | cp -d on/off | HDCP prop set + HWC read(신규 te) | |
| 44 | resolution -t hd -r 1080p | DisplayHal commitMode (실해상도 전환) | |
| 45 | ip -d on/off | network_config.conf 기록 + 재부팅 + dhcp_client 적용 | |
| 46 | ip -i ... -s ssid | 정적 IP 기록 + 재부팅 + 적용 + show ip Mode=STATIC | |
| 47 | autotest start/stop | native-dm uinput runner + vendor.iptv.autotest | |
| 48 | HiddenMenu AutoTest 시작/정지키/자연종료 | skia 529/530 + stop key + poll(신규 수정) | |
| 49 | setpvs tb (호스트 기록+자동리부팅) | persist.sys.pvs.server | |
| 50 | sys init / factory reset / fw upgrade / reboot | 파괴적 — 마지막에 | |

## 알려진 한계 (스모크 단계)
- show igmp / igmp emm: 디바이스의 구버전 iptvplayservice에 EMM 메서드 없음 → FAILED 정상.
- show qc: /tmp 쓰기 sepolicy 거부 가능 → burn 후 재확인 (marusystem tmpfs write 미허용 시 NG).
- autotest(CLI): uinput은 기존 sepolicy 허용이라 스모크 가능할 수도.
