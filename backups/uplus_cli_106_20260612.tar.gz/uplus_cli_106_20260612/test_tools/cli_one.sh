#!/bin/bash
# Send one CLI command via telnet and print its raw output.
# Usage: cli_one.sh "<command>"
IP="${CLI_IP:-192.168.123.106}"
export CLI_TIMEOUT="${CLI_TIMEOUT:-25}"
CMD="$1"
expect -f - <<EOF 2>/dev/null
set timeout $::env(CLI_TIMEOUT)
log_user 0
spawn telnet $IP 23
expect {
    -re {[Ll]ogin:} {}
    timeout { puts "TIMEOUT_LOGIN"; exit 1 }
}
send "root\r"
expect -re {[Pp]assword:}
send "qkdthdtpsxj!\r"
expect -re {#}
log_user 1
send "$CMD\r"
expect {
    -re {\n[^\n]*#[ ]?$} {}
    timeout { puts "TIMEOUT_CMD" }
}
log_user 0
send "exit\r"
expect eof
EOF
echo ""
