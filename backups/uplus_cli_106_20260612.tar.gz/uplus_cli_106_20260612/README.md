# uplus-cli 106 integration backup (2026-06-12)

vendor/marusys working-tree snapshot taken before other sessions touch the tree.

## Contents
- BASE_COMMIT.txt        : HEAD this patch applies to (b2954948...)
- all_changes_vs_HEAD.patch : staged+unstaged tracked changes (68 files, +3750/-838)
- GIT_STATUS.txt         : porcelain status at snapshot time
- untracked/tasks/       : test matrix, impl map, todo/lessons
- untracked/docs/        : prior-session untracked docs (QC v1.71 summary etc.)
- test_tools/cli_one.sh  : single-command telnet CLI tester (CLI_IP=, CLI_TIMEOUT=)
- test_tools/full_capture.txt : raw outputs of the full 55-command live run
- test_tools/sub106_original.patch : original 106-server diff (pre-integration reference)

## Restore
cd /home/kyc/work/uplus_wifi/vendor/marusys
git stash -u   # or commit/clean the tree first
git checkout $(cat BASE_COMMIT.txt) -- . 2>/dev/null || true  # optional: align base
git apply --3way all_changes_vs_HEAD.patch
cp -r untracked/tasks/* tasks/
